package com.example.jersan.utils

class Constants {
    companion object {
        val KEY_REV = "keyrev"
        val KEY_USER = "keyuser"
    }
}